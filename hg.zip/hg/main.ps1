function startGoose {

Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName PresentationCore

$timeout = 3600 # 1 hour in seconds
$stopTime = (Get-Date).AddSeconds($timeout)

start-process $env:TEMP\hg\GooseDesktop.exe

while (1){
    $Lctrl = [Windows.Input.Keyboard]::IsKeyDown([System.Windows.Input.Key]::'LeftCtrl')
    $Rctrl = [Windows.Input.Keyboard]::IsKeyDown([System.Windows.Input.Key]::RightCtrl)

    if ($Rctrl -and $Lctrl) {powershell $env:TEMP\hg\CloseGoose.bat;exit}
    #elseif ((Get-Date) -ge $stopTime) {powershell $env:TEMP\hg\CloseGoose.bat;exit}
    else {continue}
}
}

function Target-Comes {
Add-Type -AssemblyName System.Windows.Forms
$originalPOS = [System.Windows.Forms.Cursor]::Position.X
$o=New-Object -ComObject WScript.Shell

    while (1) {
        $pauseTime = 3
        if ([Windows.Forms.Cursor]::Position.X -ne $originalPOS){
            break
        }
        else {
            Start-Sleep -Seconds $pauseTime
        }
    }
}

Target-Comes
startGoose

